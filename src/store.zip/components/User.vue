<template>
  <div class="user">
    <div class="user__avatar" :style="{ 'background-color': avatarColor }">
      {{ initiales }}
    </div>
    <div class="user__information">
      <div class="user__name">
        {{ userFullName }}
      </div>
      <div class="user__age">Возраст: {{ data.age }}</div>
    </div>

    <div class="user__rating">
      <div class="user__rating-num">{{ data.rating }}</div>
      <div class="user__rating-label">баллов</div>
    </div>
  </div>
</template>

<style scoped>
.user {
  display: grid;
  grid-template-columns: auto 1fr auto;
  grid-gap: 1rem;
  width: 100%;
}

.user__avatar {
  width: 50px;
  height: 50px;
  display: flex;
  align-items: center;
  justify-content: center;
  font-weight: bold;
  border-radius: 100px;
}

.user__information {
  display: flex;
  flex-direction: column;
  justify-content: center;
}

.user__name {
  font-weight: bold;
}

.user__age {
  color: grey;
  margin-top: 0.25rem;
  font-weight: 400;
  font-size: 0.9rem;
}

.user__rating-num {
  text-align: right;
  font-weight: bold;
  font-size: 1.25rem;
}

.user__rating-label {
  color: grey;
  font-weight: 500;
  font-size: 0.85rem;
}
</style>

<script>
export default {
  name: "v-user",
  props: {
    data: {
      type: Object,
      required: true
    }
  },

  computed: {
    userFullName() {
      return `${this.data.name} ${this.data.secondName}`;
    },
    initiales() {
      return this.data.name[0] + this.data.secondName[0];
    },

    avatarColor() {
      let hash = 0;
      const fullname = this.userFullName.trim();

      for (let i = 0; i < fullname.length; i++) {
        hash = fullname.charCodeAt(i) + ((hash << 5) - hash);
      }

      const h = hash % 360;
      return `hsl(${h}, 30%, 80%)`;
    }
  }
};
</script>
