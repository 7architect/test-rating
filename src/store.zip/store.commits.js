export const LOAD_USERS = "load_users";
export const SET_GOLD = "set_gold";
export const SET_SILVER = "set_silver";
export const SET_BRONZE = "set_bronze";
export const SORT = "sort_users";

export default {
  LOAD_USERS,
  SET_GOLD,
  SET_SILVER,
  SET_BRONZE,
  SORT
};
