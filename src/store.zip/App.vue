<template>
  <div id="app">
    <header class="header">
      <div class="header__top">
        <v-heading>Рейтинг участников</v-heading>
        <button class="header__search-btn" @click="showSearch = !showSearch" />
      </div>
      <input
        class="header__search-input"
        type="search"
        placeholder="Тестер тестов"
        v-model="searchStr"
        v-show="showSearch"
      />
    </header>

    <main>
      <div class="users">
        <div class="users__sort">
          <div
            :class="{
              'users__sort-label': true,
              'users__sort-label--active': orderBy === 'rating',
              'users__sort-label--icon-desc': orderDir === 'desc' && orderBy === 'rating'
            }"
            @click="toggleOrder('rating')">по рейтингу</div>
            <div
              :class="{
                'users__sort-label': true,
                'users__sort-label--active': orderBy === 'age',
                'users__sort-label--icon-desc': orderDir === 'desc' && orderBy === 'age'
              }"
              @click="toggleOrder('age')">по возрасту</div>
        </div>

        <div class="users__list">
          <div
            class="users__list-item"
            v-for="(user, key) in users"
            :key="key"
          >
            <div class="users__list-index"> {{ ++key }} </div>
            <v-user :data="user" />
          </div>
        </div>
      </div>
    </main>
  </div>
</template>

<style>
@import url("https://fonts.googleapis.com/css?family=Oswald:300,400,600,700&display=swap&subset=cyrillic");

#app {
  font-family: "Oswald", sans-serif;
  margin: 0 auto;
  padding-top: 2rem;
  width: 700px;
}

.header__top {
  display: flex;
  justify-content: space-between;
  align-items: center
}

.header__search-btn {
  border: 0;
  width: 30px;
  height: 30px;
  background-image: url('assets/search.svg');
  background-repeat: no-repeat;
  background-color: transparent;
  background-size: contain;
  background-position: center center;
}
.header__search-input {
  width: 100%;
  padding: 0.5rem 1rem;
  margin-bottom: 1rem;
  border-width: 1px;
  border-bottom: 2px solid rgba(0, 0, 0, .3);
  outline: none;
}
.users__sort {
  display: flex;
  margin-bottom: 1rem;
}
.users__sort-label {
  margin-right: 2rem;
  opacity: 0.5;
  display: flex;
  align-items: center;
  transition: 0.15s linear;
  transition-property: opacity, transform
}

.users__sort-label:hover,
.users__sort-label--active {
  transform: scale(1.1);
  cursor: pointer;
  opacity: 1;
}

.users__sort-label::after {
  content: '';
  width: 15px;
  height: 15px;
  margin-left: 5px;
  margin-top: 3px;
  background-image: url('assets/sort.svg');
  background-repeat: no-repeat;
  background-color: transparent;
  background-size: contain;
  background-position: center center;
  display: block;
  opacity: 0.8;
}
.users__sort-label--icon-desc::after {
  transform: rotate(180deg)
}
</style>

<script>
import VHeading from "./components/Heading";
import VUser from "./components/User";
import { mapActions } from "vuex";

export default {
  components: {
    VHeading,
    VUser
  },

  data() {
    return {
      searchStr: "",
      showSearch: false,
      orderBy: "rating",
      orderDir: "asc"
    };
  },

  computed: {
    users() {
      return this.$store.getters.usersBy({
        field: this.orderBy,
        dir: this.orderDir,
        search: this.searchStr
      });
    }
  },

  methods: {
    ...mapActions(["loadUsers", "sort"]),
    toggleOrder(field) {
      if (this.orderBy !== field) {
        this.orderDir = 'asc'
      } else this.orderDir = this.orderDir === 'asc' ? 'desc' : 'asc'

      this.orderBy = field
    }
  },

  mounted() {
    this.loadUsers().then(() => {});
  }
};
</script>
